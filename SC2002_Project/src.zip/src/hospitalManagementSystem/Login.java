package hospitalManagementSystem;

import java.util.List;

public class Login {

    // Method to authenticate a user and return role-specific values
    public static int authenticate(List<User> userList, String userID, String password) {
        for (User user : userList) {
            // Check if userID and password match
            if (User.getUserId().equals(userID) && user.getPassword().equals(password)) {
                // If the user is of type Staff, cast and check the role
                if (user instanceof Staff) {
                    Staff staff = (Staff) user;  // Cast to Staff to access role
                    if (staff.getRole().equals("Pharmacist")) {
                        return 1;  // Return 1 if role is Pharmacist
                    } else if (staff.getRole().equals("Doctor")) {
                        return 2;  // Return 2 if role is Doctor
                    }
                }
            }
        }
        return -1;  // Return -1 if authentication fails
    }
}
