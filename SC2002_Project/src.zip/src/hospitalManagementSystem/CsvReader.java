package hospitalManagementSystem;

public interface CsvReader {
    void readCsv(String filePath);
}