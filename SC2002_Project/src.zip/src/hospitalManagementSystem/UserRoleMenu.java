package hospitalManagementSystem;

import java.util.Scanner;

public interface UserRoleMenu {
    void displayMenu(Scanner scanner);
}
