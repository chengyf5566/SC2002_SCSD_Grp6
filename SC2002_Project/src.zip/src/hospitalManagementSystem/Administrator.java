package hospitalManagementSystem;

public class Administrator {

}
